package api

type ApiGroup struct {
	Api
}

var ApiGroupApp = new(ApiGroup)
