package global

import "github.com/flipped-aurora/gin-vue-admin/server/plugin/notify/config"

var GlobalConfig_ = &config.DingDing{}
