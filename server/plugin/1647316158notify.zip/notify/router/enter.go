package router

type RouterGroup struct {
	NotifyRouter
}

var RouterGroupApp = new(RouterGroup)
