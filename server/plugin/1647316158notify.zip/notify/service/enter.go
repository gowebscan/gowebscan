package service

type ServiceGroup struct {
	NotifyService
}

var ServiceGroupApp = new(ServiceGroup)
